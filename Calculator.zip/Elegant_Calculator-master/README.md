# Elegant_Calculator
Features - 
1) Responsive UI.
2) It can perform all basic operations.
3) IOS like UI.

[![Calculator-Screenshot.png](https://i.postimg.cc/nzqysW22/Calculator-Screenshot.png)](https://postimg.cc/phXG4qg5)
